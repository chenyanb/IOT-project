var OIC = require('../oic/oic');
var DEV = require('iotivity-node')("client");
var IOT = require( "iotivity-node/lowlevel" );
var CLT = require("node-rest-client").Client;

const RESOURCE_FOUND_EVENT = "resourcefound";
const RESOURCE_CHANGE_EVENT = "change";
const RESOURCE_DELETE_EVENT = "delete";
const DEVICE_FOUND_EVENT = "devicefound";
const PLATFORM_FOUND_EVENT = "platformfound";

const timeoutValue = 5000; // 5s
const timeoutStatusCode = 504; // Gateway Timeout

const okStatusCode = 200; // All right
const noContentStatusCode = 204; // No content
const internalErrorStatusCode = 500; // Internal error
const badRequestStatusCode = 400; // Bad request
const notFoundStatusCode = 404; // Not found

var discoveredResources = [];
var discoveredDevices = [];
var discoveredPlatforms = [];
var obsHdlRecept = {};

var lightObsCnt;
var obsRespCnt = 0;

var flag_obs = false;  //obs 请求标志，当obs为false时 flag_obs设置为true,表示“观察结束

// Turn on global presence listening
DEV.subscribe().then(
    function() {
        console.log("Subscribed for the presence notifications.");
    },
    function(error) {
        console.log("device.subscribe() failed with: ", error);
    });

var routes = function(req, res) {
    if (req.path == '/res')
        discoverResources(req, res);
    else if (req.path == '/d')
        discoverDevices(req, res);
    else if (req.path == '/p')
        discoverPlatforms(req, res);
    else {
        if (req.method == "GET") {
            if (req.path == '/put/a/refrigerator') {
                req.path = '/a/refrigerator';
                req.method = "PUT";
                handleResPut(req, res);
            }
//when req.path = "/a/refrigerator", we should check the value of obs
            else if ( typeof req.query.obs != "undefined") {
                if ( req.query.obs == "true") {
        
                    if (req.path == '/a/refrigerator') {
                       flag_obs = false;
                    //if and only if obs = true and url = /a/refrigerator/
                        handleRescObs(req, res);
                    }                
                   req.query.obs = true;
                }else if ( req.query.obs == "false"){
                    if (req.path == '/a/light') {
                       flag_obs = true;
                        res.writeHead(okStatusCode, {'Content-Type':'text/plain'})
                        res.end("refrigerator obs is false and Resource observing canceled.");
                    }                
                }
            }
            else {
                //ilegal get url
                handleResourceGet(req, res);
            }
        }
        else if (req.method == "PUT")
            handleResourcePut(req, res);
        else {
            res.writeHead(badRequestStatusCode, {'Content-Type':'text/plain'});
            res.end("Unsupported method: " + req.method);
        }
    }

    function onResourceFound(event) {
        var resource = OIC.parseRes(event);
        discoveredResources.push(resource);
    }

    function onDeviceFound(event) {
        var device = OIC.parseDevice(event);
        discoveredDevices.push(device);
    }

    function onPlatformFound(event) {
        var platform = OIC.parsePlatform(event);
        discoveredPlatforms.push(platform);
    }

    function notSupported(req, res) {
        res.writeHead(internalErrorStatusCode, {'Content-Type':'text/plain'})
        res.end("Not supported operation: " + req.method + " " + req.path);
    }

    function discoverResources(req, res) {
        console.log("discoverResources");
        res.setTimeout(timeoutValue, function() {
            DEV.removeEventListener(RESOURCE_FOUND_EVENT, onResourceFound);
            res.writeHead(okStatusCode, 'Content-Type', 'application/json');
            res.end(JSON.stringify(discoveredResources));
        });
        console.log("%s %s", req.method, req.url);
        discoveredResources.length = 0;
        DEV.addEventListener(RESOURCE_FOUND_EVENT, onResourceFound);
        console.log("Discovering resources for %d seconds.", timeoutValue/1000);
        DEV.findResources().then(function() {
            // TODO: should we send in-progress back to http-client
            console.log("findResources() successful");
        })
        .catch(function(e) {
            res.writeHead(internalErrorStatusCode, {'Content-Type':'text/plain'})
            res.end("Error: " + e.message);
        });
    }
    function discoverDevices(req, res) {
        res.setTimeout(timeoutValue, function() {
            DEV.removeEventListener(DEVICE_FOUND_EVENT, onDeviceFound);
            res.writeHead(okStatusCode, {'Content-Type': 'application/json'});
            res.end(JSON.stringify(discoveredDevices));
        });

        console.log("%s %s", req.method, req.url);

        discoveredDevices.length = 0;
        DEV.addEventListener(DEVICE_FOUND_EVENT, onDeviceFound);

        console.log("Discovering devices for %d seconds.", timeoutValue/1000);
        DEV.findDevices().then(function() {
            // TODO: should we send in-progress back to http-client
            console.log("findDevices() successful");
        })
        .catch(function(e) {
            res.writeHead(internalErrorStatusCode, {'Content-Type':'text/plain'})
            res.end("Error: " + e.message);
        });
    }

    function discoverPlatforms(req, res) {
        res.setTimeout(timeoutValue, function() {
            DEV.removeEventListener(PLATFORM_FOUND_EVENT, onPlatformFound);
            res.writeHead(okStatusCode, {'Content-Type': 'application/json'});
            res.end(JSON.stringify(discoveredPlatforms));
        });

        console.log("%s %s", req.method, req.url);

        discoveredPlatforms.length = 0;
        DEV.addEventListener(PLATFORM_FOUND_EVENT, onPlatformFound);

        console.log("Discovering platforms for %d seconds.", timeoutValue/1000);
        DEV.findPlatforms().then(function() {
            console.log("findPlatforms() successful");
        })
        .catch(function(e) {
            res.writeHead(internalErrorStatusCode, {'Content-Type':'text/plain'})
            res.end("Error: " + e.message);
        });
    }

    function obsRespHdlr( handle, response ) {
            console.log( "light1 Received response to OBSERVE request:" );
            obsRespCnt++;
            if ( obsRespCnt == 1 ) {
                return IOT.OCStackApplicationResult.OC_STACK_KEEP_TRANSACTION;
             } //else if (obsRespCnt > 100){
            //     console.log( "Enough observations(100). Calling OCCancel()" );
            //     IOT.OCCancel(
            //         handle,
            //         IOT.OCQualityOfService.OC_HIGH_QOS,
            //         []);
            //     return IOT.OCStackApplicationResult.OC_STACK_DELETE_TRANSACTION;
            // }  
            //flag_obs == false           
            if ( flag_obs) {
                console.log( "light1 obs is false. Calling OCCancel()" );
                IOT.OCCancel(
                    handle,
                    IOT.OCQualityOfService.OC_HIGH_QOS,
                    []);
                return IOT.OCStackApplicationResult.OC_STACK_DELETE_TRANSACTION;
            } else {
              // var bearer,sdid;                 // var sdid = "DEVICE_ID";  var bearer = "Bearer DEVICE_TOKEN";
               var artikcloud = "https://api.artik.cloud/v1.1/messages";
               var clt = new CLT();
               var ts = new Date().valueOf();
               var bearer = "Bearer ede270662c1745b6898c4c32fca33033";
               var sdid = "4a9180498f654baf86f6ea4093ea5a74";
               console.log("light1.state : "+response.payload.values.state);
               console.log("light1.power : "+response.payload.values.power);
               var args = {
                    headers: {
                        "Content-Type": "application/json",
                        "Authorization": bearer
                    },
                    data: {
                        "sdid": sdid,
                        "ts": ts,
                        "type": "message",
                        "data": {
                            "state": response.payload.values.state,
                            "power": response.payload.values.power
                        }
                    }
                };
                clt.post(artikcloud, args, function(data, response) {
                    console.log(data);
                });
                return IOT.OCStackApplicationResult.OC_STACK_KEEP_TRANSACTION;
            }

    };
    function handleRescObs(req, res) {
        //res.writeHead(okStatusCode, {'Content-Type':'text/plain'})
        //res.end("Query parameter \"obs\" is set.");

        // Screening
        if (typeof req.query.di == "undefined") {
            res.writeHead(badRequestStatusCode, {'Content-Type':'text/plain'})
            res.end("Query parameter \"di\" is missing.");
            return;
        }

        console.log( "light1 Observing " + req.path + ' from ' + req.query.di);
        IOT.OCDoResource(
            obsHdlRecept,
            IOT.OCMethod.OC_REST_OBSERVE,
            req.path,
            DEV._devices[req.query.di].address,
            null,
            IOT.OCConnectivityType.CT_DEFAULT,
            IOT.OCQualityOfService.OC_HIGH_QOS,
            obsRespHdlr,
            null);
            res.writeHead(okStatusCode, {'Content-Type':'text/plain'})
            res.end("light1 obs is true and Resource observing started.");
        return IOT.OCStackApplicationResult.OC_STACK_KEEP_TRANSACTION;
    }
    function handleResourceGet(req, res) {

        // Screening
        if (typeof req.query.di == "undefined") {
            res.writeHead(badRequestStatusCode, {'Content-Type':'text/plain'})
            res.end("Query parameter \"di\" is missing.");
            return;
        }
        console.log("%s %s (fd: %d)", req.method, req.url, req.socket._handle.fd);

        function observer(event) {
            var fd = (res.socket._handle == null) ? -1 : res.socket._handle.fd;
            console.log("obs: %d, fin: %s, di: %s, fd: %d",req.query.obs, res.finished, req.query.di, fd);
            if (req.query.obs == "true" && res.finished == false) {
                lightObsCnt++;
                var json = OIC.parseResource(event.resource);
                res.write(json);
                if ( lightObsCnt > 4 ) {
                    res.finished = true;
                    res.end();
                }
            } else {
                event.resource.removeEventListener(RESOURCE_CHANGE_EVENT, observer);
                event.resource.removeEventListener(RESOURCE_DELETE_EVENT, deleteHandler);
            }
        }

        function deleteHandler(event) {
            console.log("Resource %s has been deleted", req.url);
            if (req.query.obs == true && res.finished == false) {
                res.end();
            }
        }
        

        DEV.retrieve({deviceId: req.query.di, path: req.path}, req.query).then(
            function(resource) {
                if (req.query.obs != "undefined" && req.query.obs == "true") {
                    req.on('close', function() {
                        console.log("Client: close");
                        req.query.obs = false;
                    });
                    res.writeHead(okStatusCode, {'Content-Type':'application/json'});
                    resource.addEventListener(RESOURCE_CHANGE_EVENT, observer);
                    resource.addEventListener(RESOURCE_DELETE_EVENT, deleteHandler);
                } else {
                    var json = OIC.parseResource(resource);
                    res.writeHead(okStatusCode, {'Content-Type':'application/json'});
                    res.end(json);
                }
            },
            function(error) {
                res.writeHead(notFoundStatusCode, {'Content-Type':'text/plain'})
                res.end("Resource retrieve failed: " + error.message);
            }
        );
    }

    function handleResourcePut(req, res) {
        if (typeof req.query.di == "undefined") {
            res.writeHead(badRequestStatusCode, {'Content-Type':'text/plain'})
            res.end("Query parameter \"di\" is missing.");
            return;
        }

        res.setTimeout(timeoutValue, function() {
            res.writeHead(notFoundStatusCode, {'Content-Type':'text/plain'})
            res.end("Resource not found.");
        });

        var body = [];
        req.on('data', function(chunk) {
            body.push(chunk);
        }).on('end', function() {
            body = Buffer.concat(body).toString();
            var resource = {
                id: {deviceId: req.query.di, path: req.path},
                properties: JSON.parse(body)
            };
            console.log("PUT %s: %s", req.originalUrl, JSON.stringify(resource));
            DEV.update(resource).then(
                function() {
                    res.statusCode = noContentStatusCode;
                    res.end();
                },
                function(error) {
                    res.writeHead(notFoundStatusCode, {'Content-Type':'text/plain'})
                    res.end("Resource update failed: " + error.message);
                }
            );
        });
    }

    function handleResPut(req, res) {
        var isUpdate = -1;
        if (typeof req.query.di == "undefined") {
            res.writeHead(badRequestStatusCode, {'Content-Type':'text/plain'})
            res.end("Query parameter \"di\" is missing.");
            return;
        }

        if (typeof req.query.state == "undefined") {
            res.writeHead(badRequestStatusCode, {'Content-Type':'text/plain'})
            res.end("Query parameter \"state\" is missing.");
            return;
        }

        if (typeof req.query.power == "undefined") {
            res.writeHead(badRequestStatusCode, {'Content-Type':'text/plain'})
            res.end("Query parameter \"power\" is missing.");
            return;
        }

        res.setTimeout(timeoutValue, function() {
            if(res.isUpdate==1){
                res.writeHead(notFoundStatusCode, {'Content-Type':'text/plain'})
                 res.end("Resource updated.");

            }else{
                res.writeHead(notFoundStatusCode, {'Content-Type':'text/plain'})
                res.end("Resource not found.");
            }
        });
        var body = '{\"state\":' + req.query.state + ',' + '\"power\":' + req.query.power + '}';
        var resource = {
            id: {deviceId: req.query.di, path: req.path},
            properties: JSON.parse(body)
        };
        console.log("PUT %s: %s", req.originalUrl, JSON.stringify(resource));
        DEV.update(resource).then(
            function() {
              //   res.statusCode = noContentStatusCode;
                res.isUpdate = 1;
                // res.writeHead(okStatusCode, {'Content-Type':'text/plain'})
                // res.end("light1 Resource update succeeded.");
                console.log("light Resource update succeeded.");
            },
            function(error) {
                res.isUpdate = -1;
                // res.writeHead(notFoundStatusCode, {'Content-Type':'text/plain'})
                // res.end("light1 Resource update failed: " + error.message);
                console.log("light Resource update failed.");
            }
        );
    }
}
module.exports = routes;
