var OIC = require('../oic/oic');
var DEV = require('iotivity-node')("client");
var IOT = require( "iotivity-node/lowlevel" );
var CLT = require("node-rest-client").Client;
const RESOURCE_FOUND_EVENT = "resourcefound";
const RESOURCE_CHANGE_EVENT = "change";
const RESOURCE_DELETE_EVENT = "delete";
const DEVICE_FOUND_EVENT = "devicefound";
const PLATFORM_FOUND_EVENT = "platformfound";
const timeoutValue = 2000; // 5s
const timeoutStatusCode = 504; // Gateway Timeout
const okStatusCode = 200; // All right
const noContentStatusCode = 204; // No content
const internalErrorStatusCode = 500; // Internal error
const badRequestStatusCode = 400; // Bad request
const notFoundStatusCode = 404; // Not found
var discoveredResources = [];
var discoveredDevices = [];
var discoveredPlatforms = [];
//*********************************************
var updateInfo = "";
// Turn on global presence listening
DEV.subscribe().then(
    function() {
        console.log("Subscribed for the presence notifications yes.");
    },
    function(error) {
        console.log("device.subscribe() failed with: ", error);
    });
var subPath="";
var routes = function(req, res) {
    var orginalPath = req.path;
    console.log("originalPath**************"+orginalPath);
    subPath = orginalPath.substring(8);//subPath will dynamically change  according to the different request.
    console.log("subPath**************"+subPath);
    if (subPath == '/res')
        discoverResources(req, res);
    else if (subPath == '/d')
        discoverDevices(req, res);
    else if (subPath == '/p')
        discoverPlatforms(req, res);
    else if (req.method == "GET" || req.method == "PUT") {
        if(subPath.startsWith("/put/a")){
            subPath = subPath.substring(4);
            req.method = "PUT";
            handleResPut(req,res);
        } else if(subPath.startsWith("/a")){
            handleResourceGet(req, res);//show the messages on browser     
        } else {
            notSupported(req, res);
        }
    } else {
        notSupported(req, res);
    }   
    };
    function onResourceFound(event) {
        var resource = OIC.parseRes(event);//print the payload
        discoveredResources.push(resource);
    }

    function onDeviceFound(event) {
        var device = OIC.parseDevice(event);
        discoveredDevices.push(device);
    }

    function onPlatformFound(event) {
        var platform = OIC.parsePlatform(event);
        discoveredPlatforms.push(platform);
    }

    function notSupported(req, res) {
        res.writeHead(internalErrorStatusCode, {'Content-Type':'text/plain'})
        res.end("Not supported operation: " + req.method + " " + subPath);
    }
    function discoverResources(req, res) {
        console.log("discoverResources");
        //After 5s, response run the function
        res.setTimeout(timeoutValue, function() {
            DEV.removeEventListener(RESOURCE_FOUND_EVENT, onResourceFound);//through onResourceFound print payload
            console.log("====================show original devices============== ");
            //console.log(discoveredResources);
             console.log("=======================================================");
             var devices = {};//to store all devices
            discoveredResources.forEach((item)=>{
                // item is a resource,object
                for(var attr in item){
                    if(attr=="di"){
                        _di = item[attr];
                    }
                    if(attr=="links"){
                        var obj = item[attr];//obj is a array and only has a element.
                      //  console.log(obj);
                        obj.forEach((value)=>{
                              for(var subattr in value){
                            if(subattr=="href"&&value[subattr].startsWith("/a/")){
                                var currentDev={};
                                var device  = value[subattr].substring(3);
                                currentDev.id= _di;
                                currentDev.show=req.protocol+"://192.168.0.111:8000/api/oic"+value[subattr]+"?di="+_di+"&obs=true";
                                currentDev.name = device;
                                devices[device] = currentDev; //add a device
                            }
                        }
                        });

                    }
                }
            });
            //sort devices
            var sortedDevices = {};
            var sortedKey = Object.keys(devices).sort();
            console.log("=======sort devices=============="+sortedKey);
            sortedKey.forEach((item) =>{
                sortedDevices[item] = devices[item];
            })
            
            console.log("====================show ultimate devices =================");
            for(var attr in sortedDevices){
                var detail = sortedDevices[attr];
                console.log(attr);
                for(subattr in detail){
                    console.log("   "+subattr+":"+detail[subattr]);
                }
            }
             console.log("=========================================================");
             res.render('resource', {devices:sortedDevices});
        });

        console.log("%s %s", req.method, req.url);

        discoveredResources.length = 0;
        DEV.addEventListener(RESOURCE_FOUND_EVENT, onResourceFound);

        console.log("Discovering resources for %d seconds.", timeoutValue/1000);
        DEV.findResources().then(function() {
            // TODO: should we send in-progress back to http-client
            console.log("findResources() successful");
        })
        .catch(function(e) {
            res.writeHead(internalErrorStatusCode, {'Content-Type':'text/plain'})
            res.end("Error: " + e.message);
        });
    }

    function discoverDevices(req, res) {
        res.setTimeout(timeoutValue, function() {
            DEV.removeEventListener(DEVICE_FOUND_EVENT, onDeviceFound);
            // res.writeHead(okStatusCode, {'Content-Type': 'application/json'});
            // res.end(JSON.stringify(discoveredDevices));
            console.log(discoveredDevices);
            res.render('trick', { test: "devices" });
            res.end();
        });

        console.log("%s %s", req.method, req.url);

        discoveredDevices.length = 0;
        DEV.addEventListener(DEVICE_FOUND_EVENT, onDeviceFound);

        console.log("Discovering devices for %d seconds.", timeoutValue/1000);
        DEV.findDevices().then(function() {
            // TODO: should we send in-progress back to http-client
            console.log("findDevices() successful");
        })
        .catch(function(e) {
            res.writeHead(internalErrorStatusCode, {'Content-Type':'text/plain'})
            res.end("Error: " + e.message);
        });
    }

    function discoverPlatforms(req, res) {
        res.setTimeout(timeoutValue, function() {
            DEV.removeEventListener(PLATFORM_FOUND_EVENT, onPlatformFound);
            //res.writeHead(okStatusCode, {'Content-Type': 'application/json'});
           // res.end(JSON.stringify(discoveredPlatforms));
           res.render("trick", {test : "platforms"});
        });

        console.log("%s %s", req.method, req.url);

        discoveredPlatforms.length = 0;
        DEV.addEventListener(PLATFORM_FOUND_EVENT, onPlatformFound);

        console.log("Discovering platforms for %d seconds.", timeoutValue/1000);
        DEV.findPlatforms().then(function() {
            console.log("findPlatforms() successful");
        })
        .catch(function(e) {
            res.writeHead(internalErrorStatusCode, {'Content-Type':'text/plain'})
            res.end("Error: " + e.message);
        });
    }

    function handleResourceGet(req, res) {
        if (typeof req.query.di == "undefined") {
            res.writeHead(badRequestStatusCode, {'Content-Type':'text/plain'})
            res.end("Query parameter \"di\" is missing.");
            return;
        }
        console.log("%s %s (fd: %d)", req.method, req.url, req.socket._handle.fd);
        DEV.retrieve({deviceId: req.query.di, path: subPath}, req.query).then(
            function(resource) {
                    var json = OIC.parseResource(resource);
                    var Resstate = JSON.parse(json);
                    var deviceInfo = {};
                    console.log("===============original state=======================");
                    console.log(Resstate);
                    console.log("====================================================");
                    info = {};
                    for(var subattr in Resstate.properties){
                        info[subattr] = Resstate["properties"][subattr];
                    }
                    backData = {};
                    backData.id = req.query.di;
                    backData.name =  subPath.substring(3);
                    backData.update=req.protocol+"://192.168.0.111:8000/api/oic/put"+subPath;
                    backData.mainIndex = req.protocol + "://192.168.0.111:8000/api/oic/res";
                    backData.updateInfo = updateInfo;
                    updateInfo = "";
                    res.render('deviceState', {info:info,backData:backData});
                    res.end();
            },
            function(error) {
                res.writeHead(notFoundStatusCode, {'Content-Type':'text/plain'})
                res.end("Resource retrieve failed: " + error.message);
            }
        );
    }
    function handleResourcePut(req, res) {
        if (typeof req.query.di == "undefined") {
            res.writeHead(badRequestStatusCode, {'Content-Type':'text/plain'})
            res.end("Query parameter \"di\" is missing.");
            return;
        }
        res.setTimeout(timeoutValue, function() {
            res.writeHead(notFoundStatusCode, {'Content-Type':'text/plain'})
            res.end("Resource not found.");
        });
        var body = [];
        req.on('data', function(chunk) {
            body.push(chunk);
        }).on('end', function() {
            body = Buffer.concat(body).toString();
            var resource = {
                id: {deviceId: req.query.di, path: subPath},
                properties: JSON.parse(body)
            };
            console.log("PUT %s: %s", req.originalUrl, JSON.stringify(resource));
            DEV.update(resource).then(
                function() {
                    res.statusCode = noContentStatusCode;
                    res.end();
                },
                function(error) {
                    res.writeHead(notFoundStatusCode, {'Content-Type':'text/plain'})
                    res.end("Resource update failed: " + error.message);
                }
            );
        });
    }

    function handleResPut(req, res) {
        var deviceName = subPath.substring(3);
        var parameters = req.query;
        var body='';
        for(var attr in parameters){
            if (parameters[attr] == "") {
                updateInfo = "Arguments can not be null";
                handleResourceGet(req, res);
                return;
            }
            if(attr!="di"){
                body = body+',"'+attr+'":'+'"'+parameters[attr]+'"';
            }
        }
        body = '{'+body.substring(1)+'}';
        console.log("====================body=========================");
        console.log(body);
         console.log("=============================================");
        // var body = '{\"state\":' +'"'+ req.query.state + '",' + '\"power\":' + req.query.power + '}';
        var resource = {
            id: {deviceId: req.query.di, path: subPath},
            properties: JSON.parse(body)
        };
        console.log("PUT %s: %s", req.originalUrl, JSON.stringify(resource));
        DEV.update(resource).then(
            function() {
            console.log(deviceName+" Resource update succeeded.");
            updateInfo = "Updated successfully";
            handleResourceGet(req, res);
            },
            function(error) {
                console.log(deviceName+" Resource update failed." + error.message);
            }
        );
    }
module.exports = routes;
