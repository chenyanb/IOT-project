a = {
        "sdid": 123,
        "ts": "hello",
        "type": "message",
        "data": {
            "state": "on",
            "power": 100
        }
 }
 b = {
        sdid: 123,
        ts: "hello",
        type: "message",
        data: {
            state: "on",
            power: 100
        }
 }
 c = {
     a_b:12,
     "a-b":5
 }
//  console.log(c)
//  console.log(c["a-b"]);
//  console.log(b.sdid);
if(4){
    console.log("it ok ");
}
function come () {
    console.log("exception?");
    throw new Error("hello");
} 
function on() {
    try {
        come();
    } catch(e) {
        console.log(e.message);
        console.log(e.stack);
    }
    console.log("after err");
    
}
on();

function honor(exception) {
    try {
        throw exception;
    } catch (e) {
        console.log(e);
    }
}
honor("just");