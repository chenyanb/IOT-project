var express = require("express");
var path = require('path');
var favicon = require('serve-favicon');
var logger = require('morgan');
var cookieParser = require('cookie-parser');
var bodyParser = require('body-parser');



var app = express();
app.set('views', path.join(__dirname, 'views'));
app.set('view engine', 'ejs');

//uncomment after placing your favicon in /public
//app.use(favicon(path.join(__dirname, 'public', 'favicon.ico')));
app.use(logger('dev'));
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: false }));
app.use(cookieParser());
app.use(express.static(path.join(__dirname, 'public')));
var http, https;
var router = require('./router');
var routes = {};

function start(config, options) {
    function onRequest(req, res) {
        if (config.cors) {
            // Allow cross origin requests
            res.setHeader('Access-Control-Allow-Origin', '*');
            res.setHeader("Access-Control-Allow-Headers", "Origin, X-Requested-With, Content-Type, Accept");
        }
        console.log("run server--start--onRequest");
        router.route(routes, req, res);
    }
    if (config.https) {
        https = require('https');
       // https.createServer(options, onRequest).listen(config.port);
       https.createServer(options,app).listen(config.port,()=>{
           console.log("https is running on port "+config.port);
       });
       app.use((req,res,next)=>{
           onRequest(req,res);
       });
    }
    else {
        // http = require('http');
        // http.createServer(onRequest).listen(config.port);
        app.listen(config.port);
        console.log("http is running on port "+config.port);
        app.use(function(req,res,next){
                onRequest(req,res);
        });
        
    }
    console.log("API server started on " + new Date().toISOString()
        + " [port: " + config.port + ", https: " + config.https + "]");
}

function use(pathname, handler) {
    if (typeof handler === 'function'){
        routes[pathname] = handler;
        console.log(`server.use = ${pathname}`);
       // console.log(pathname+"***************"+handler.toString());
    }
    else
        console.log("Server: handler is not a function");
}

exports.use = use;
exports.start = start;
