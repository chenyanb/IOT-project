///<reference path="/opt/nodeSnippet/typings/index.d.ts"/>
var os = require('os');
var routes = function(req, res) {
    info(req, res);

    function info(req, res) {
        console.log("sysHandler");
        var system = {};

        system.hostname = os.hostname();
        system.type = os.type();
        system.platform = os.platform();
        system.arch = os.arch();
        system.release = os.release();
        system.uptime = os.uptime();
        system.loadavg = os.loadavg();
        system.totalmem = os.totalmem();
        system.freemem = os.freemem();
        system.cpus = os.cpus();
        system.networkinterfaces = os.networkInterfaces();
        //cpus is a arch
        /*
        cpus: [
                    {
                        model: "Intel(R) Core(TM) i7-4790 CPU @ 3.60GHz",
                        speed: 3591,
                        times: {
                        user: 74900,
                        nice: 32000,
                        sys: 188500,
                        idle: 4057400,
                        irq: 0
                        }
                    },
                    {
                        model: "Intel(R) Core(TM) i7-4790 CPU @ 3.60GHz",
                        speed: 3591,
                        times: {
                        user: 66800,
                        nice: 14500,
                        sys: 187300,
                        idle: 4306500,
                        irq: 0
                        }
                    }
                    ],
        */
        var count = 1;
        system.cpus.forEach(function(item){
           //item is a object
           for(var attr in item){
               if(typeof item[attr]=="object"){
                   for(var subattr in item[attr])
                        system["cpu"+count+"_"+attr+"_"+subattr]= item[attr][subattr];
               }else
               system["cpu"+count+"_"+attr] = item[attr];
           } 
           count++;
        });
          // console.log(system);
       
        for(var attr in system.networkinterfaces){
             var ipType = "ipv4";
           (system.networkinterfaces)[attr].forEach((item)=>{
               //item is a object
               for(var subattr in item){
                   system["network_"+attr+"_"+ipType+"_"+subattr] = item[subattr];
               }
               ipType="ipv6";
           });
          
        }
        /**
         * loadavg: [
            0.0498046875,
            0.19677734375,
            0.13037109375
            ],
         */
        count =1 ;
        system.loadavg.forEach((item)=>{
            system["loadavg_"+(count++)]= item;
        })
       // console.log(system);
        /**
         * networkinterfaces: {
lo: [
        {
        address: "127.0.0.1",
        netmask: "255.0.0.0",
        family: "IPv4",
        mac: "00:00:00:00:00:00",
        internal: true
        },
        {
        address: "::1",
        netmask: "ffff:ffff:ffff:ffff:ffff:ffff:ffff:ffff",
        family: "IPv6",
        mac: "00:00:00:00:00:00",
        scopeid: 0,
        internal: true
        }
        ],
eth0: [
        {
        address: "192.168.0.111",
        netmask: "255.255.255.0",
        family: "IPv4",
        mac: "00:0c:29:ef:27:50",
        internal: false
        },
        {
        address: "fe80::20c:29ff:feef:2750",
        netmask: "ffff:ffff:ffff:ffff::",
        family: "IPv6",
        mac: "00:0c:29:ef:27:50",
        scopeid: 2,
        internal: false
        }
        ]
},
         */
     
        // res.render('index', { hostname: system.hostname,
        //                         type: system.type ,
        //                         arch : system.arch,
        //                         release:system.release,
        //                         uptime:system.uptime,
        //                         fremem:system.freemem,
        //                         totalmem:system.totalmem,
        //                         cpu1model:system.cpus   
        //                  });
        res.render("systemInfo",system);
    //    res.writeHead(200, {"Content-Type": "application/json"});
    //   res.end(JSON.stringify(system));
      res.end();
    }

}
module.exports = routes;
