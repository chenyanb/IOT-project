var OIC = require('../oic/oic');
var DEV = require('iotivity-node')("client");
var IOT = require( "iotivity-node/lowlevel" );
var CLT = require("node-rest-client").Client;
const RESOURCE_FOUND_EVENT = "resourcefound";
const RESOURCE_CHANGE_EVENT = "change";
const RESOURCE_DELETE_EVENT = "delete";
const DEVICE_FOUND_EVENT = "devicefound";
const PLATFORM_FOUND_EVENT = "platformfound";

const timeoutValue = 2000; // 5s
const timeoutStatusCode = 504; // Gateway Timeout

const okStatusCode = 200; // All right
const noContentStatusCode = 204; // No content
const internalErrorStatusCode = 500; // Internal error
const badRequestStatusCode = 400; // Bad request
const notFoundStatusCode = 404; // Not found

var discoveredResources = [];
var discoveredDevices = [];
var discoveredPlatforms = [];
//*********************************************
var deviceObsCnt = 0; 
var flag_obs = false;
var obsHdlRecept = {};
var obsResCnt = { };
var devicesObs = { }; //check whether invoke the obs
var isDeviceObs = {};
var isFirstStart;
//var reobs={} ;   //obs start again flag
//*********************************************
// Turn on global presence listening
DEV.subscribe().then(
    function() {
        console.log("Subscribed for the presence notifications yes.");
    },
    function(error) {
        console.log("device.subscribe() failed with: ", error);
    });
var subPath="";
var routes = function(req, res) {
    if(isFirstStart == undefined) {
        isFirstStart = true;   //ensure  the web page start with  discoverResources;
    }else{                    //if you try to start with other page than force begin with discoverResources page
        isFirstStart = false;
    }   
    console.log("req.path**************"+req.path);
    var orginalPath = req.path;  //  /api/oic/res   GET 
    subPath = orginalPath.substring(8);//subPath will dynamically change  according to the different request.
     console.log("subPath**************"+subPath);  //subPath is the characteristor after "oic"
        if (subPath == '/res')
        discoverResources(req, res);
    else if (subPath == '/d')
        discoverDevices(req, res);
    else if (subPath == '/p')
        discoverPlatforms(req, res);
    else { 
        if (isFirstStart==true){
            discoverResources(req, res);
        }else {    
        if (req.method == "GET") {
        //if the request is to update /put/a/...
            if(subPath.startsWith("/put/a")){
                subPath = subPath.substring(4);  //delete  "/put "
                req.method = "PUT";   //change the method
                handleResPut(req,res);   //process handle of "/put/a/"
            }else if(subPath.startsWith("/a")){    
                 handleResourceGet(req, res);//show the messages on browser   
                if(req.query.obs=="true"){  //req is unique
                    if(devicesObs[subPath.substring(3)]==undefined){//if not the first requirest obs=true,not enter
                        devicesObs[subPath.substring(3)] = true;    //the first time obs=true;
                       // flag_obs = false;
                       isDeviceObs[subPath.substring(3)] = false;
                        handleRescObs(req,res);   //push the messages to the cloud 
                    }
                }else if(req.query.obs=="false"){
                    isDeviceObs[subPath.substring(3)] = true;//the flag of stop obs
                    delete devicesObs[subPath.substring(3)]; //delete the flag ,in order to restart "obs=true"
                    console.log(subPath.substring(3)+" obs is false and Resource observing canceled.");
                } else {   //wrong parameter of "obs"
                    res.writeHead(notFoundStatusCode, {'Content-Type':'text/plain'})
                    res.end("the parameter of \"obs\" is wrong,the type of\"obs\" must be boolean");
                } 
            }
            else {
                handleResourceGet(req, res);
            }
        }
        else if (req.method == "PUT")
            handleResourcePut(req, res);
        else {
            res.writeHead(badRequestStatusCode, {'Content-Type':'text/plain'});
            res.end("Unsupported method: " + req.method);
        }
    }
        }
    function updateDeviceInfo(subPath){

    }
    function onResourceFound(event) {
        var resource = OIC.parseRes(event);//print the payload
        discoveredResources.push(resource);
    }

    function onDeviceFound(event) {
        var device = OIC.parseDevice(event);
        discoveredDevices.push(device);
    }

    function onPlatformFound(event) {
        var platform = OIC.parsePlatform(event);
        discoveredPlatforms.push(platform);
    }

    function notSupported(req, res) {
        res.writeHead(internalErrorStatusCode, {'Content-Type':'text/plain'})
        res.end("Not supported operation: " + req.method + " " + subPath);
    }
    function handleRescObs(req, res) {
        var deviceName = subPath.substring(3);//subPath:/a/light1    req.path:  /api/oic/a/light1
        console.log(subPath+":"+req.path);
        console.log( deviceName+" Observing " +subPath + ' from ' + req.query.di);
        IOT.OCDoResource(
            obsHdlRecept,
            IOT.OCMethod.OC_REST_OBSERVE,
            subPath,
            DEV._devices[req.query.di].address,
            null,
            IOT.OCConnectivityType.CT_DEFAULT,
            IOT.OCQualityOfService.OC_HIGH_QOS,
            obsRespHdlr,
            null);
        console.log(deviceName+" obs is true and Resource observing started.");
        return IOT.OCStackApplicationResult.OC_STACK_KEEP_TRANSACTION;
    }
        function obsRespHdlr( handle, response ) {
            
            console.log("=============================execute obsRespHdlr=======================");
            var device  = response.resourceUri.substring(3);     //get device name
           // console.log( device+" Received response to OBSERVE request:" );
            if(obsResCnt[device]== undefined){   //first enter
                obsResCnt[device] = 1;   
            }else{
                obsResCnt[device]++;
            }
            if ( obsResCnt[device] == 1 ) {
                return IOT.OCStackApplicationResult.OC_STACK_KEEP_TRANSACTION;  //init 
             }   
            if (isDeviceObs[device]) {
                console.log( device+"obs is false. Calling OCCancel()" );
                delete obsResCnt[device];   //when obs is false then clear the counter
                IOT.OCCancel(
                    handle,
                    IOT.OCQualityOfService.OC_HIGH_QOS,
                    []);
                return IOT.OCStackApplicationResult.OC_STACK_DELETE_TRANSACTION;
            } else {
               console.log(`******* ${device} to the artik cloud *******************`);
              // var bearer,sdid;  // var sdid = "DEVICE_ID";  var bearer = "Bearer DEVICE_TOKEN";
               var artikcloud = "https://api.artik.cloud/v1.1/messages";
               var clt = new CLT();
               var ts = new Date().valueOf();
               var cloud_id={};
               cloud_id.light1="26426e6485084e93bbfd9bdf84604193";
               cloud_id.light2="e848e718eacb4c0fae72eba8519cce58";
               cloud_id.light3="1440cde30ad443998da961b1c4a5236c";
               cloud_id.refrigerator="64c71b2da498454696b0e9fc3c73c9ac";
               var cloud_token={};
               cloud_token.light1="Bearer f8f1bcebd219465d93de185c8abc8c44";
               cloud_token.light2="Bearer ef7963fc1cce43739806fbc68ea316c1";
               cloud_token.light3="Bearer b6154c629d844088996f9d12ed761102";
               cloud_token.refrigerator="Bearer 2db4b42a67154063b5c90fca42791eb5";
               for(var key in cloud_id){
                    if(key==device){
                        sdid=cloud_id[device];
                    }
               }
               for(var key in cloud_token){
                    if(key==device){
                        bearer=cloud_token[device];
                    }
               }
            //    var bearer = "Bearer 16faed7cda2b42a8953944ac4fb1acd0";
            //    var sdid = "4e277db639f4424198f84e08bb201bce";
              console.log(response.payload.values);
              console.log("*****************************************************");
               var args = {
                    headers: {
                        "Content-Type": "application/json",
                        Authorization: bearer
                    }, 
                    data: {
                        sdid: sdid,
                        ts: ts,
                        type: "message",
                        data:response.payload.values
                    }
                };
                clt.post(artikcloud, args, function(data, response) {
                    console.log(`${device} push successfully`);
                });
                return IOT.OCStackApplicationResult.OC_STACK_KEEP_TRANSACTION;
            }

    }
    function discoverResources(req, res) {
        console.log("discoverResources");
        //res.setTimeout() after 5s ,response run the function
        res.setTimeout(timeoutValue, function() {
            DEV.removeEventListener(RESOURCE_FOUND_EVENT, onResourceFound);//through onResourceFound print payload
        //    console.log("====================show original devices============== ");
            console.log(discoveredResources);
          //   console.log("=======================================================");
             var devices = {};//to store all devices
            discoveredResources.forEach((item)=>{
                // item is a resource,object
                for(var attr in item){
                    if(attr=="di"){
                        _di = item[attr];
                    }
                    if(attr=="links"){
                        var obj = item[attr];//obj is a array and only has a element.     what is the use of obj   
                       // console.log("99999999999999999999999999999999999"+obj);     
                        obj.forEach((value)=>{
                          
                              for(var subattr in value){  
                                 console.log(" value[subattr]9999999999999999999999999999999"+subattr+": "+ value[subattr]);
                            if(subattr=="href"&&value[subattr].startsWith("/a/")){
                                var currentDev={};
                                var device  = value[subattr].substring(3);   //store device name
                                currentDev.id= _di;
                                currentDev.show=req.protocol+"://192.168.0.111:8000/api/oic"+value[subattr]+"?di="+_di+"&obs=true";
                                //////
                                currentDev.name = device;
                                devices[device] = currentDev; //add a device
                            }
                        }
                        });

                    }
                }
            });
            console.log("====================show ultimate devices =================");
            for(var attr in devices){
                var detail = devices[attr];
                console.log(attr);
                for(subattr in detail){
                    console.log("   "+subattr+":"+detail[subattr]);
                }
            }     
             console.log("=========================================================");
             res.render('resource', {devices:devices});    // 
        });

        console.log("%s %s", req.method, req.url);
        //    GET  /api/oic/res

        discoveredResources.length = 0;
        DEV.addEventListener(RESOURCE_FOUND_EVENT, onResourceFound);

        console.log("Discovering resources for %d seconds.", timeoutValue/1000);
        DEV.findResources().then(function() {
            // TODO: should we send in-progress back to http-client
            console.log("findResources() successful");
        })
        .catch(function(e) {
            res.writeHead(internalErrorStatusCode, {'Content-Type':'text/plain'})
            res.end("Error: " + e.message);
        });
    }

    function discoverDevices(req, res) {
        res.setTimeout(timeoutValue, function() {
            DEV.removeEventListener(DEVICE_FOUND_EVENT, onDeviceFound);
            // res.writeHead(okStatusCode, {'Content-Type': 'application/json'});
            // res.end(JSON.stringify(discoveredDevices));
            res.render('index', { title: "ocfHandler" });
            res.end();
        });

        console.log("%s %s", req.method, req.url);

        discoveredDevices.length = 0;
        DEV.addEventListener(DEVICE_FOUND_EVENT, onDeviceFound);

        console.log("Discovering devices for %d seconds.", timeoutValue/1000);
        DEV.findDevices().then(function() {
            // TODO: should we send in-progress back to http-client
            console.log("findDevices() successful");
        })
        .catch(function(e) {
            res.writeHead(internalErrorStatusCode, {'Content-Type':'text/plain'})
            res.end("Error: " + e.message);
        });
    }

    function discoverPlatforms(req, res) {
        res.setTimeout(timeoutValue, function() {
            DEV.removeEventListener(PLATFORM_FOUND_EVENT, onPlatformFound);
            res.writeHead(okStatusCode, {'Content-Type': 'application/json'});
            res.end(JSON.stringify(discoveredPlatforms));
        });

        console.log("%s %s", req.method, req.url);

        discoveredPlatforms.length = 0;
        DEV.addEventListener(PLATFORM_FOUND_EVENT, onPlatformFound);

        console.log("Discovering platforms for %d seconds.", timeoutValue/1000);
        DEV.findPlatforms().then(function() {
            console.log("findPlatforms() successful");
        })
        .catch(function(e) {
            res.writeHead(internalErrorStatusCode, {'Content-Type':'text/plain'})
            res.end("Error: " + e.message);
        });
    }

    function handleResourceGet(req, res) {

        if (typeof req.query.di == "undefined") {
            res.writeHead(badRequestStatusCode, {'Content-Type':'text/plain'})
            res.end("Query parameter \"di\" is missing.");
            return;
        }
        console.log("%s %s (fd: %d)", req.method, req.url, req.socket._handle.fd);
       //                                GET        /api/oic/a/light2?di=.......&obs=false     
        function observer(event) {
            var fd = (res.socket._handle == null) ? -1 : res.socket._handle.fd;
            console.log("obs: %d, fin: %s, di: %s, fd: %d",req.query.obs, res.finished, req.query.di, fd);
            if (req.query.obs == true && res.finished == false) {
                deviceObsCnt ++;
                var json = OIC.parseResource(event.resource);
                res.write(json);
                if(deviceObsCnt >4){
                    res.finished =true;
                    res.end();
                }
            } else {
                event.resource.removeEventListener(RESOURCE_CHANGE_EVENT, observer);
                event.resource.removeEventListener(RESOURCE_DELETE_EVENT, deleteHandler);
            }
        }
        function deleteHandler(event) {
            console.log("Resource %s has been deleted", req.url);
            if (req.query.obs == true && res.finished == false) {
                res.end();
            }
        }
        DEV.retrieve({deviceId: req.query.di, path: subPath}, req.query).then(
            function(resource) {
                if (req.query.obs != "undefined" && req.query.obs == true) {
                    req.on('close', function() {
                        console.log("Client: close");
                        req.query.obs = false;
                    });
                    res.writeHead(okStatusCode, {'Content-Type':'application/json'});
                    resource.addEventListener(RESOURCE_CHANGE_EVENT, observer);
                    resource.addEventListener(RESOURCE_DELETE_EVENT, deleteHandler);
                } else {
                    var json = OIC.parseResource(resource);
                    console.log("json00000000000000"+json);
                    var Resstate = JSON.parse(json);
                    var deviceInfo = {};
                    console.log("===============original state=======================");
                    console.log(Resstate);
                    console.log("====================================================");
                    info = {};
                    for(var subattr in Resstate.properties){
                        info[subattr] = Resstate["properties"][subattr];
                    }
                    backData = {};
                    backData.id = req.query.di;
                    backData.name =  subPath.substring(3);  //light1,devicename
                    backData.update=req.protocol+"://192.168.0.111:8000/api/oic/put"+subPath;
                    res.render('deviceState', {info:info,backData:backData});
                    res.end();
                }
            },
            function(error) {
                res.writeHead(notFoundStatusCode, {'Content-Type':'text/plain'})
                res.end("Resource retrieve failed: " + error.message);
            }
        );
    }
    function handleResourcePut(req, res) {
        if (typeof req.query.di == "undefined") {
            res.writeHead(badRequestStatusCode, {'Content-Type':'text/plain'})
            res.end("Query parameter \"di\" is missing.");
            return;
        }
        res.setTimeout(timeoutValue, function() {
            res.writeHead(notFoundStatusCode, {'Content-Type':'text/plain'})
            res.end("Resource not found.");
        });
        var body = [];
        req.on('data', function(chunk) {
            body.push(chunk);
        }).on('end', function() {
            body = Buffer.concat(body).toString();
            var resource = {
                id: {deviceId: req.query.di, path: subPath},
                properties: JSON.parse(body)
            };
            console.log("PUT %s: %s", req.originalUrl, JSON.stringify(resource));
            DEV.update(resource).then(
                function() {
                    res.statusCode = noContentStatusCode;
                    res.end();
                },
                function(error) {
                    res.writeHead(notFoundStatusCode, {'Content-Type':'text/plain'})
                    res.end("Resource update failed: " + error.message);
                }
            );
        });
    }
    function devicetype(deviceName,parameters) {
        if(deviceName == "refrigerator")  {
            if(isNaN(parameters.ctemp)) {       //ctemp not a number
             res.writeHead(badRequestStatusCode, {'Content-Type':'text/plain'})
            res.end("Query parameter \"ctemp\" is not a number.");
            return;
            } 
             if(isNaN(parameters.ftemp)) {       //ftemp not a number
             res.writeHead(badRequestStatusCode, {'Content-Type':'text/plain'})
             res.end("Query parameter \"ftemp\" is not a number.");
            return;
            }
          //  console.log(typeof( parameters.state)+typeof( parameters.ctemp)+typeof( parameters.state));
            if(parameters.state !="true"&& parameters.state !="false") {
                res.writeHead(badRequestStatusCode, {'Content-Type':'text/plain'})
                res.end("Query parameter \"state\" is not a boolean type .");
                return;
            }            
        }
        if(deviceName.slice(0,5) == "light") {      
            if(parameters.state !="true"&& parameters.state !="false") {   //state  type judge
                res.writeHead(badRequestStatusCode, {'Content-Type':'text/plain'})
                res.end("Query parameter \"state\" is not a boolean type .");
                return;
            }
            if(isNaN(parameters.power)) {       //power not a number
             res.writeHead(badRequestStatusCode, {'Content-Type':'text/plain'})
            res.end("Query parameter \"power\" is not a number.");
            return;
            } 
        }
        return;
    }
    function handleResPut(req, res) {
        var deviceName = subPath.substring(3);  //device name 
        var parameters = req.query;    //device properties
        var isUpdate = -1;
        
        devicetype(deviceName,parameters);  //parameter judge
        // if(isNaN(JSON.parse(parameters).ctemp)    // isNaN(val) when is number then return false
        res.setTimeout(timeoutValue, function() {
            /***
            console.log("resource is not found");
            // res.writeHead(notFoundStatusCode, {'Content-Type':'text/plain'})
            // res.end("Resource not found.");
            res.render("stateUpdate",{title:"resource updated"});
            */
             if(res.isUpdate==1){
                res.writeHead(notFoundStatusCode, {'Content-Type':'text/plain'})
                 res.end("the state of "+ deviceName + " updated.");

            }else{
                res.writeHead(notFoundStatusCode, {'Content-Type':'text/plain'})
                res.end("Resource not found.");
            }
        });
        console.log("*************");
        var body='';
        for(var attr in parameters){
            if(attr!="di"&&attr!="obs"){
                body = body+',"'+attr+'":'+'"'+parameters[attr]+'"';
                console.log(body);
            }
        }
        body = '{'+body.substring(1)+'}';
        console.log("====================body=========================");
        console.log(body);
         console.log("=============================================");
        // var body = '{\"state\":' +'"'+ req.query.state + '",' + '\"power\":' + req.query.power + '}';
        var resource = {
            id: {deviceId: req.query.di, path: subPath},
            properties: JSON.parse(body)
        };
        console.log("PUT %s: %s", req.originalUrl, JSON.stringify(resource));
        DEV.update(resource).then(
            function() {
                res.isUpdate = 1;
            console.log(deviceName+" Resource update succeeded.");
            },
            function(error) {
                res.isUpdate = -1;
                console.log(deviceName+" Resource update failed.");
            }
        );
    }
}
module.exports = routes;
