var OIC = require('../oic/oic');
var DEV = require('iotivity-node')("client");
var IOT = require( "iotivity-node/lowlevel" );
var CLT = require("node-rest-client").Client;
const RESOURCE_FOUND_EVENT = "resourcefound";
const RESOURCE_CHANGE_EVENT = "change";
const RESOURCE_DELETE_EVENT = "delete";
const DEVICE_FOUND_EVENT = "devicefound";
const PLATFORM_FOUND_EVENT = "platformfound";

const timeoutValue = 2000; // 5s
const timeoutStatusCode = 504; // Gateway Timeout

const okStatusCode = 200; // All right
const noContentStatusCode = 204; // No content
const internalErrorStatusCode = 500; // Internal error
const badRequestStatusCode = 400; // Bad request
const notFoundStatusCode = 404; // Not found

var discoveredResources = [];
var discoveredDevices = [];
var discoveredPlatforms = [];
//*********************************************
var deviceObsCnt = 0; 
var flag_obs = false;
var obsHdlRecept = {};
var obsResCnt = { };
var devicesObs = { }; //check whether invoke the obs
var isDeviceObs = {};
//*********************************************
// Turn on global presence listening
DEV.subscribe().then(
    function() {
        console.log("Subscribed for the presence notifications yes.");
    },
    function(error) {
        console.log("device.subscribe() failed with: ", error);
    });
    
var subPath="";
var routes = function(req, res) {
    //console.log("req.path**************"+req.path);
    var orginalPath = req.path;
    subPath = orginalPath.substring(8);//subPath will dynamically change  according to the different request.
     console.log("subPath**************"+subPath);
        if (subPath == '/res')
        discoverResources(req, res);
    else if (subPath == '/d')
        discoverDevices(req, res);
    else if (subPath == '/p')
        discoverPlatforms(req, res);
    else {
        if (req.method == "GET") {
        //if the request is to update /put/a/...
            if(subPath.startsWith("/put/a")){
                subPath = subPath.substring(4);
                req.method = "PUT";
                handleResPut(req,res);
            }else if(subPath.startsWith("/a")){
                 handleResourceGet(req, res);//show the messages on browser   
                if(req.query.obs=="true"){  //req is unique
                    if(devicesObs[subPath.substring(3)]==undefined){
                        devicesObs[subPath.substring(3)] = true;
                       // flag_obs = false;
                       isDeviceObs[subPath.substring(3)] = false;
                        handleRescObs(req,res);   //push the messages to the cloud 
                    }
                }else{
                    isDeviceObs[subPath.substring(3)] = true;
                    delete devicesObs[subPath.substring(3)]; //delete the flag ,in order to restart "obs=true"
                    console.log(subPath.substring(3)+" obs is false and Resource observing canceled.");
                }  
            }
            else {
                handleResourceGet(req, res);
            }
        }
        else if (req.method == "PUT")
            handleResourcePut(req, res);
        else {
            res.writeHead(badRequestStatusCode, {'Content-Type':'text/plain'});
            res.end("Unsupported method: " + req.method);
        }
    }
    function updateDeviceInfo(subPath){

    }
    function onResourceFound(event) {
        var resource = OIC.parseRes(event);//print the payload
        discoveredResources.push(resource);
    }

    function onDeviceFound(event) {
        var device = OIC.parseDevice(event);
        discoveredDevices.push(device);
    }

    function onPlatformFound(event) {
        var platform = OIC.parsePlatform(event);
        discoveredPlatforms.push(platform);
    }

    function notSupported(req, res) {
        res.writeHead(internalErrorStatusCode, {'Content-Type':'text/plain'})
        res.end("Not supported operation: " + req.method + " " + subPath);
    }
    function handleRescObs(req, res) {
        var deviceName = subPath.substring(3);
        console.log( deviceName+" Observing " +subPath + ' from ' + req.query.di);
        IOT.OCDoResource(
            obsHdlRecept,
            IOT.OCMethod.OC_REST_OBSERVE,
            subPath,
            DEV._devices[req.query.di].address,
            null,
            IOT.OCConnectivityType.CT_DEFAULT,
            IOT.OCQualityOfService.OC_HIGH_QOS,
            obsRespHdlr,
            null);
        console.log(deviceName+" obs is true and Resource observing started.");
        return IOT.OCStackApplicationResult.OC_STACK_KEEP_TRANSACTION;
    }
    function obsRespHdlr( handle, response ) {
        console.log("=============================execute obsRespHdlr=======================");
        var device  = response.resourceUri.substring(3);
        console.log( device+" Received response to OBSERVE request:" );
            if(obsResCnt[device]==undefined){
                obsResCnt[device] = 1;
            }else{
                obsResCnt[device]++;
            }
            if ( obsResCnt[device] == 1 ) {
                return IOT.OCStackApplicationResult.OC_STACK_KEEP_TRANSACTION;
             }   
            if (isDeviceObs[device]) {
                console.log( device+"obs is false. Calling OCCancel()" );
                IOT.OCCancel(
                    handle,
                    IOT.OCQualityOfService.OC_HIGH_QOS,
                    []);
                return IOT.OCStackApplicationResult.OC_STACK_DELETE_TRANSACTION;
            } else {
               console.log(`******* ${device} to the artik cloud *******************`);
              // var bearer,sdid;  // var sdid = "DEVICE_ID";  var bearer = "Bearer DEVICE_TOKEN";
               var artikcloud = "https://api.artik.cloud/v1.1/messages";
               var clt = new CLT();
               var ts = new Date().valueOf();
               var cloud_id={};
               cloud_id.light1="4e277db639f4424198f84e08bb201bce";
               cloud_id.light2="48e3df7064524a8ca67000b25de060ef";
               cloud_id.light3="d27815b241c9480387cef9dbbed3b9f1";
               cloud_id.refrigerator="3e5794fa70d64bd8b0082e3f4a10cff6";
               var cloud_token={};
               cloud_token.light1="Bearer 49ef18fde536443a87657bee25e7dec8";
               cloud_token.light2="Bearer b29217b2a3724d9e87498478726d842f";
               cloud_token.light3="Bearer 77e1eb5730e049b195f5082ee985f958";
               cloud_token.refrigerator="Bearer 97d8d443205d4710986df47763c22be3";
               for(var key in cloud_id){
                    if(key==device){
                        sdid=cloud_id[device];
                    }
               }
               for(var key in cloud_token){
                    if(key==device){
                        bearer=cloud_token[device];
                    }
               }   
              console.log(response.payload.values);
              console.log("*****************************************************");
               var args = {
                    headers: {
                        "Content-Type": "application/json",
                        Authorization: bearer
                    }, 
                    data: {
                        sdid: sdid,
                        ts: ts,
                        type: "message",
                        data:response.payload.values
                    }
                };
                clt.post(artikcloud, args, function(data, response) {
                    //console.log(`${device} push successfully`);
                    console.log(data);
                });
                return IOT.OCStackApplicationResult.OC_STACK_KEEP_TRANSACTION;
            }

    }
    function discoverResources(req, res) {
        console.log("discoverResources");
        //res.setTimeout() after 5s ,response run the function
        res.setTimeout(timeoutValue, function() {
            DEV.removeEventListener(RESOURCE_FOUND_EVENT, onResourceFound);//through onResourceFound print payload
            console.log("====================show original devices============== ");
            console.log(discoveredResources);
             console.log("=======================================================");
             var devices = {};//to store all devices
            discoveredResources.forEach((item)=>{
                // item is a resource,object
                for(var attr in item){
                    if(attr=="di"){
                        _di = item[attr];
                    }
                    if(attr=="links"){
                        var obj = item[attr];//obj is a array and only has a element.
                        console.log(obj+"*************************");
                        obj.forEach((value)=>{
                              for(var subattr in value){
                            if(subattr=="href"&&value[subattr].startsWith("/a/")){
                                var currentDev={};
                                var device  = value[subattr].substring(3);
                                currentDev.id= _di;
                                currentDev.show=req.protocol+"://192.168.1.220:8000/api/oic"+value[subattr]+"?di="+_di+"&obs=true";
                                currentDev.name = device;
                                devices[device] = currentDev; //add a device
                            }
                        }
                        });

                    }
                }
            });
            console.log("====================show ultimate devices =================");
            for(var attr in devices){
                var detail = devices[attr];
                console.log(attr);
                for(subattr in detail){
                    console.log("   "+subattr+":"+detail[subattr]);
                }
            }
             console.log("=========================================================");
             res.render('resource', {devices:devices});
        });

        console.log("%s %s", req.method, req.url);

        discoveredResources.length = 0;
        DEV.addEventListener(RESOURCE_FOUND_EVENT, onResourceFound);

        console.log("Discovering resources for %d seconds.", timeoutValue/1000);
        DEV.findResources().then(function() {
            // TODO: should we send in-progress back to http-client
            console.log("findResources() successful");
        })
        .catch(function(e) {
            res.writeHead(internalErrorStatusCode, {'Content-Type':'text/plain'})
            res.end("Error: " + e.message);
        });
    }

    function discoverDevices(req, res) {
        res.setTimeout(timeoutValue, function() {
            DEV.removeEventListener(DEVICE_FOUND_EVENT, onDeviceFound);
            // res.writeHead(okStatusCode, {'Content-Type': 'application/json'});
            // res.end(JSON.stringify(discoveredDevices));
            res.render('index', { title: "ocfHandler" });
            res.end();
        });

        console.log("%s %s", req.method, req.url);

        discoveredDevices.length = 0;
        DEV.addEventListener(DEVICE_FOUND_EVENT, onDeviceFound);

        console.log("Discovering devices for %d seconds.", timeoutValue/1000);
        DEV.findDevices().then(function() {
            // TODO: should we send in-progress back to http-client
            console.log("findDevices() successful");
        })
        .catch(function(e) {
            res.writeHead(internalErrorStatusCode, {'Content-Type':'text/plain'})
            res.end("Error: " + e.message);
        });
    }

    function discoverPlatforms(req, res) {
        res.setTimeout(timeoutValue, function() {
            DEV.removeEventListener(PLATFORM_FOUND_EVENT, onPlatformFound);
            res.writeHead(okStatusCode, {'Content-Type': 'application/json'});
            res.end(JSON.stringify(discoveredPlatforms));
        });

        console.log("%s %s", req.method, req.url);

        discoveredPlatforms.length = 0;
        DEV.addEventListener(PLATFORM_FOUND_EVENT, onPlatformFound);

        console.log("Discovering platforms for %d seconds.", timeoutValue/1000);
        DEV.findPlatforms().then(function() {
            console.log("findPlatforms() successful");
        })
        .catch(function(e) {
            res.writeHead(internalErrorStatusCode, {'Content-Type':'text/plain'})
            res.end("Error: " + e.message);
        });
    }

    function handleResourceGet(req, res) {

        if (typeof req.query.di == "undefined") {
            res.writeHead(badRequestStatusCode, {'Content-Type':'text/plain'})
            res.end("Query parameter \"di\" is missing.");
            return;
        }
        console.log("%s %s (fd: %d)", req.method, req.url, req.socket._handle.fd);

        function observer(event) {
            var fd = (res.socket._handle == null) ? -1 : res.socket._handle.fd;
            console.log("obs: %d, fin: %s, di: %s, fd: %d",req.query.obs, res.finished, req.query.di, fd);
            if (req.query.obs == true && res.finished == false) {
                deviceObsCnt ++;
                var json = OIC.parseResource(event.resource);
                res.write(json);
                if(deviceObsCnt >4){
                    res.finished =true;
                    res.end();
                }
            } else {
                event.resource.removeEventListener(RESOURCE_CHANGE_EVENT, observer);
                event.resource.removeEventListener(RESOURCE_DELETE_EVENT, deleteHandler);
            }
        }
        function deleteHandler(event) {
            console.log("Resource %s has been deleted", req.url);
            if (req.query.obs == true && res.finished == false) {
                res.end();
            }
        }
        DEV.retrieve({deviceId: req.query.di, path: subPath}, req.query).then(
            function(resource) {
                if (req.query.obs != "undefined" && req.query.obs == true) {
                    req.on('close', function() {
                        console.log("Client: close");
                        req.query.obs = false;
                    });
                    res.writeHead(okStatusCode, {'Content-Type':'application/json'});
                    resource.addEventListener(RESOURCE_CHANGE_EVENT, observer);
                    resource.addEventListener(RESOURCE_DELETE_EVENT, deleteHandler);
                } else {
                    var json = OIC.parseResource(resource);
                    var Resstate = JSON.parse(json);
                    var deviceInfo = {};
                    console.log("===============original state=======================");
                    console.log(Resstate);
                    console.log("====================================================");
                    info = {};
                    for(var subattr in Resstate.properties){
                        info[subattr] = Resstate["properties"][subattr];
                    }
                    backData = {};
                    backData.id = req.query.di;
                    backData.name =  subPath.substring(3);
                    backData.update=req.protocol+"://192.168.1.220:8000/api/oic/put"+subPath;
                    res.render('deviceState', {info:info,backData:backData});
                    res.end();
                }
            },
            function(error) {
                res.writeHead(notFoundStatusCode, {'Content-Type':'text/plain'})
                res.end("Resource retrieve failed: " + error.message);
            }
        );
    }
    function handleResourcePut(req, res) {
        if (typeof req.query.di == "undefined") {
            res.writeHead(badRequestStatusCode, {'Content-Type':'text/plain'})
            res.end("Query parameter \"di\" is missing.");
            return;
        }
        res.setTimeout(timeoutValue, function() {
            res.writeHead(notFoundStatusCode, {'Content-Type':'text/plain'})
            res.end("Resource not found.");
        });

        var body = [];
        req.on('data', function(chunk) {
            body.push(chunk);
        }).on('end', function() {
            body = Buffer.concat(body).toString();
            var resource = {
                id: {deviceId: req.query.di, path: subPath},
                properties: JSON.parse(body)
            };
            console.log("PUT %s: %s", req.originalUrl, JSON.stringify(resource));
            DEV.update(resource).then(
                function() {
                    res.statusCode = noContentStatusCode;
                    res.end();
                },
                function(error) {
                    res.writeHead(notFoundStatusCode, {'Content-Type':'text/plain'})
                    res.end("Resource update failed: " + error.message);
                }
            );
        });
    }

    function handleResPut(req, res) {
        var deviceName = subPath.substring(3);
        var parameters = req.query;
         var isUpdate = -1;
        res.setTimeout(timeoutValue, function() {
            /***
            console.log("resource is not found");
            // res.writeHead(notFoundStatusCode, {'Content-Type':'text/plain'})
            // res.end("Resource not found.");
            res.render("stateUpdate",{title:"resource updated"});
            */
             if(res.isUpdate==1){
                res.writeHead(notFoundStatusCode, {'Content-Type':'text/plain'})
                 res.end("Resource updated.");

            }else{
                res.writeHead(notFoundStatusCode, {'Content-Type':'text/plain'})
                res.end("Resource not found.");
            }
        });
        console.log("*************");
        var body='';
        for(var attr in parameters){
            if(attr!="di"&&attr!="obs"){
                body = body+',"'+attr+'":'+'"'+parameters[attr]+'"';
            }
        }
        body = '{'+body.substring(1)+'}';
        console.log("====================body=========================");
        console.log(body);
         console.log("=============================================");
        // var body = '{\"state\":' +'"'+ req.query.state + '",' + '\"power\":' + req.query.power + '}';
        var resource = {
            id: {deviceId: req.query.di, path: subPath},
            properties: JSON.parse(body)
        };
        console.log("PUT %s: %s", req.originalUrl, JSON.stringify(resource));
        DEV.update(resource).then(
            function() {
                res.isUpdate = 1;
            console.log(deviceName+" Resource update succeeded.");
            },
            function(error) {
                res.isUpdate = -1;
                console.log(deviceName+" Resource update failed.");
            }
        );
    }
}
module.exports = routes;
