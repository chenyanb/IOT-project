a = {
        "sdid": 123,
        "ts": "hello",
        "type": "message",
        "data": {
            "state": "on",
            "power": 100
        }
 }
 b = {
        sdid: 123,
        ts: "hello",
        type: "message",
        data: {
            state: "on",
            power: 100
        }
 }
 c = {
     a_b:12,
     "a-b":5
 }
//  console.log(c)
//  console.log(c["a-b"]);
//  console.log(b.sdid);
if(4){
    console.log("it ok ");
}