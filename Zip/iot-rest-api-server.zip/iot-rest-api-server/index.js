var path = require('path');
var server = require("./server");
var ocf = require("./handlers/ocfHandler");
var system = require("./handlers/systemHandler");
var fs = null;
var args = process.argv.slice(2);
var options = {
    help: false,
    verbose: false,
    https: false,
    port: 8000,
    cors: false
};

const usage = "usage: node index.js [options]\n" +
"options: \n" +
"  -h, --help \n" +
"  -v, --verbose \n" +
"  -p, --port <number>\n" +
"  -s, --https \n" +
"  -c, --cors \n";

for (var i = 0; i < args.length; i++) {
    var arg = args[i];

    switch(arg) {
        case '-h':
        case '--help':
            options.help = true;
            break;
        case '-v':
        case '--verbose':
            options.verbose = true;
            break;
        case '-s':
        case '--https':
            options.https = true;
            break;
        case '-p':
        case '--port':
            var num = args[i + 1];
            if (typeof num == 'undefined') {
                console.log(usage);
                process.exit(0);
            }
            options.port = parseInt(num);
            break;
        case '-c':
        case '--cors':
            options.cors = true;
            break;
    }
}

if (options.help == true) {
    console.log(usage);
    process.exit(0);
}

if (Number.isInteger(options.port) == false) {
    console.log(usage);
    process.exit(0);
}

var httpsOptions = {key: null, cert: null};
if (options.https == true) {
    fs = require('fs');
    httpsOptions.key = fs.readFileSync(path.join(__dirname, 'config', 'server.key'));
    httpsOptions.cert = fs.readFileSync(path.join(__dirname, 'config', 'server.crt'));
}

server.use("/api/oic", ocf);
server.use("/api/system", system);

// systemd socket activation support
if (process.env.LISTEN_FDS) {
    // The first passed file descriptor is fd 3
    var fdStart = 3;
    options.port = {fd: fdStart};
}

server.start(options, httpsOptions);
